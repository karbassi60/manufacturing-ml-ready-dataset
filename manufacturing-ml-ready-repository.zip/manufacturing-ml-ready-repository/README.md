# Manufacturing ML-ready dataset — reproducibility repository

[![DOI](https://img.shields.io/badge/DOI-pending-lightgrey)](https://zenodo.org/)

Version 1.0.0 | Dataset snapshot: 2026-10-18

This repository packages a **user-provided, already-transformed** manufacturing dataset with validation, basic exploratory analysis and leakage-aware benchmark scripts. Its original collection protocol, license, raw data source, and pre-processing transformations have **not been independently verified**. Do not represent it as an original observational dataset or as evidence of deployment-level model validity without establishing provenance.

## Contents
- `data/ml_ready_full.csv` — uploaded dataset (1,000 rows, 39 columns; original content preserved).
- `scripts/validate_dataset.py` — structure, missingness, duplicate columns and target/leakage checks.
- `scripts/train_baseline.py` — stratified holdout classification benchmark with safeguards.
- `docs/DATA_DICTIONARY.csv` — dataset column names, types and short descriptions.
- `docs/DATA_PROVENANCE.md` — origin limitations, data governance and leakage cautions.
- `docs/REPRODUCIBILITY.md` — runnable commands and release procedure.
- `CITATION.cff` — GitHub/Zenodo citation metadata (DOI to be added after archival).

## Dataset snapshot
- Records: **1,000**; fields: **39**; missing cells: **0**; exact duplicate rows: **0**.
- Possible targets: `Efficiency_Level` (Low/Medium/High), `Supply_Chain_Resilience` (Low/Medium/High), or `Maintenance_Event` (binary).
- Calendar columns have two distinct value patterns: `DayOfYear`, `Month`, `DayOfYear.1`, and `Month.1` are all identical; `Weekday` and `Weekday.1` are identical. These patterns are unusual for independently derived calendar features and require an upstream preprocessing audit.
- `Supply_Chain_Resilience_High`, `_Medium`, and `_Low` are direct encodings of `Supply_Chain_Resilience`: **never use them as predictors for that target**.
- `Machine_Efficiency` may determine `Efficiency_Level`; exclude from predictors until target-generation logic is verified. No temporal out-of-sample claims should be made because this extract does not retain an original chronological timestamp.

## Setup
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/validate_dataset.py
python scripts/train_baseline.py --target Supply_Chain_Resilience
```

## Scope and limitations
The benchmark is only a **demonstration**, not a published paper result. A random stratified split cannot establish real-world forecasting performance. Some transformed features may retain source/label information; independently review feature generation before inference. Training script intentionally excludes all other named targets and resilience indicators; for `Efficiency_Level`, it additionally excludes `Machine_Efficiency` as a precaution.

## Citation and DOI
A DOI **has not yet been issued**. To obtain one, publish this as a public GitHub repository, connect that repository to Zenodo, then create a GitHub release `v1.0.0`. Replace the DOI-pending badge after Zenodo provides the actual identifier. See `docs/REPRODUCIBILITY.md`.

## Rights
The copyright and redistribution rights for the uploaded CSV have not been established. The repository contains **no asserted open-source or open-data license**. Confirm ownership and distribution permissions before publishing it publicly. Add appropriate software and data licenses only after confirming rights.
