"""Leakage-aware illustrative holdout classifier; not a forecasting validation."""
import argparse, json
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, balanced_accuracy_score

TARGETS = {'Efficiency_Level', 'Supply_Chain_Resilience', 'Maintenance_Event'}

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--target', choices=sorted(TARGETS), default='Supply_Chain_Resilience')
    p.add_argument('--seed', type=int, default=42)
    args = p.parse_args()
    df = pd.read_csv(Path(__file__).resolve().parents[1] / 'data' / 'ml_ready_full.csv')
    dropped = set(TARGETS) | {'Month', 'DayOfYear.1', 'Month.1', 'Weekday.1'}
    dropped |= {c for c in df.columns if c.startswith('Supply_Chain_Resilience_')}
    if args.target == 'Efficiency_Level':
        dropped.add('Machine_Efficiency')  # possible deterministic target derivation
    # Note: remaining source-derived features still require independent leakage review.
    X = df.drop(columns=sorted(dropped & set(df.columns))).select_dtypes(include='number')
    y = df[args.target]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=args.seed, stratify=y)
    model = make_pipeline(SimpleImputer(strategy='median'), StandardScaler(),
                          LogisticRegression(max_iter=2000, random_state=args.seed))
    model.fit(X_train, y_train)
    predicted = model.predict(X_test)
    print(json.dumps({'target': args.target, 'seed': args.seed,
        'train_rows': len(X_train), 'test_rows': len(X_test),
        'feature_count': X.shape[1], 'features': X.columns.tolist(),
        'accuracy': float(accuracy_score(y_test, predicted)),
        'macro_f1': float(f1_score(y_test, predicted, average='macro')),
        'balanced_accuracy': float(balanced_accuracy_score(y_test, predicted)),
        'note': 'Illustrative random split only; data provenance and leakage not certified.'
    }, indent=2))

if __name__ == '__main__':
    main()
