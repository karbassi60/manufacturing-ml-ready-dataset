"""Check the supplied manufacturing CSV without modifying it."""
from pathlib import Path
import hashlib, json
import pandas as pd

PATH = Path(__file__).resolve().parents[1] / 'data' / 'ml_ready_full.csv'

def main():
    data = pd.read_csv(PATH)
    duplicate_pairs = [(str(a), str(b)) for i, a in enumerate(data.columns)
                       for b in data.columns[i+1:] if data[a].equals(data[b])]
    print(json.dumps({
        'file': str(PATH), 'rows': len(data), 'columns': len(data.columns),
        'missing_cells': int(data.isna().sum().sum()),
        'duplicate_rows': int(data.duplicated().sum()),
        'duplicate_column_pairs': duplicate_pairs,
        'targets': {name: data[name].value_counts(dropna=False).to_dict()
                    for name in ('Efficiency_Level', 'Supply_Chain_Resilience', 'Maintenance_Event')},
        'sha256': hashlib.sha256(PATH.read_bytes()).hexdigest()
    }, indent=2))

if __name__ == '__main__':
    main()
