# Data provenance, governance, and limitations

- Input: CSV supplied directly by repository preparer on 2026-10-18, named `ml_ready_full 3.csv`.
- The repository renames the file to `ml_ready_full.csv` without changing the data content.
- Data collection location, entity, timeframe, sampling design, treatment of outliers, and preprocessing/scaling parameters are unknown.
- No assertion that records are real factory observations, independently collected, or synthetic can be justified from the file alone.
- Numeric features include apparently scaled values, so units cannot be recovered reliably.
- Determine whether data sharing is authorized and whether any confidential, contract-restricted, or personal information is embedded before public release.
- Duplicate calendar columns should be detected and excluded from modeling. In particular, DayOfYear/Month/DayOfYear.1/Month.1 all hold identical values and Weekday/Weekday.1 are identical.
- Supply-chain resilience one-hot features directly encode their namesake target.
- Efficiency level may be a thresholded transformation of machine efficiency; avoid target leakage by excluding this input for efficiency-level modeling pending a documented feature derivation audit.
- Another outcome column can leak related label information; baseline excludes other outcome columns to be conservative.
- No chronological evaluation is supported without reconstructing original timestamps and grouping repeated units.

## Data integrity
The uploaded bytes are retained in `data/ml_ready_full.csv`. SHA-256 of that file:

`94588e1be0867d534aada8f39e636c11e3becb36866c59521f0a6afb3e8523e7`
