# Reproduce and archive

## Local environment
Python 3.10+ recommended.

```bash
pip install -r requirements.txt
python scripts/validate_dataset.py
python scripts/train_baseline.py --target Supply_Chain_Resilience --seed 42
python scripts/train_baseline.py --target Efficiency_Level --seed 42
python scripts/train_baseline.py --target Maintenance_Event --seed 42
```

Benchmark outputs are printed in JSON. Standardized transform is confined to each training fold via a scikit-learn pipeline. Holdout is stratified with a fixed seed. These results must not be described as causal, external validation, or chronological forecasting.

## GitHub and Zenodo publication
1. Confirm data-sharing rights and choose the appropriate software/data licenses. If the CSV cannot be shared, remove it before making the repository public, and update the readme/provenance accordingly.
2. Create a **public** GitHub repository named `manufacturing-ml-ready-dataset`, then upload/commit the contents of this folder (not its containing folder).
3. Sign in at `https://zenodo.org/` via GitHub; visit `https://zenodo.org/account/settings/github/`, sync and enable the repository.
4. After enabling Zenodo, create a new GitHub release with tag `v1.0.0` and title `Dataset and reproducibility package v1.0.0`.
5. Verify Zenodo has archived that release; copy the actual version DOI into the GitHub README and `CITATION.cff`. Future GitHub releases produce additional version DOIs; Zenodo also provides a concept DOI for all versions.

The repository does not currently have a DOI. Connecting Zenodo and publishing the release requires account authorization.
